"""SAWN demonstration application. Local prototype; not an institutional deployment."""
import json
from urllib.request import Request, urlopen
from urllib.error import URLError
import re
from urllib.parse import quote, urlencode
import os, secrets, sqlite3, calendar
from pathlib import Path
from datetime import date, datetime, timedelta
from functools import wraps
from flask import Flask, render_template, redirect, url_for, request, session, flash, g, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

ROOT=Path(__file__).resolve().parent
app=Flask(__name__)
app.config['SECRET_KEY']=os.environ.get('SAWN_SECRET_KEY') or secrets.token_hex(32)
app.config['LOCAL_AI']=bool(os.environ.get('SAWN_LOCAL_MODEL'))
DB=Path(os.environ.get('SAWN_DB',str(ROOT/'sawn.db')))
STATUSES=['جديد','قيد الصيانة','مكتمل']

def db():
    if 'db' not in g:
        g.db=sqlite3.connect(DB)
        g.db.row_factory=sqlite3.Row
        g.db.execute('PRAGMA foreign_keys=ON')
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    handle=g.pop('db',None)
    if handle: handle.close()

def setup():
    with app.app_context():
        db().executescript((ROOT/'schema.sql').read_text(encoding='utf-8'))
        db().execute('BEGIN IMMEDIATE')
        additions = {'users': {'rank': "TEXT NOT NULL DEFAULT ''", 'alerts_on': 'INTEGER NOT NULL DEFAULT 1'},
                     'tickets': {'planned_date': 'TEXT', 'technician_id': 'INTEGER REFERENCES users(id)'},
                     'schedules': {'interval_months': 'INTEGER DEFAULT 0'},
                     'devices': {'whatsapp': "TEXT NOT NULL DEFAULT ''", 'email': "TEXT NOT NULL DEFAULT ''"}}
        for table, fields in additions.items():
            existing = {row['name'] for row in db().execute(f'PRAGMA table_info({table})')}
            for field, definition in fields.items():
                if field not in existing:
                    db().execute(f'ALTER TABLE {table} ADD COLUMN {field} {definition}')
        if not db().execute("SELECT 1 FROM activity_log WHERE action='history_migrated'").fetchone():
            db().execute("""INSERT INTO completed_work(source,source_id,device_id,work,technician,done_on)
                SELECT 'ticket',id,device_id,issue,technician,date(updated_at) FROM tickets WHERE status='مكتمل'""")
            db().execute("""INSERT INTO completed_work(source,source_id,device_id,work,technician,done_on,visible_to)
                SELECT 'task',t.id,t.device_id,t.title,u.display_name,date(t.updated_at),t.assigned_to FROM tasks t
                JOIN users u ON u.id=t.assigned_to WHERE t.status='completed'""")
            db().execute("""INSERT INTO completed_work(source,source_id,device_id,work,technician,done_on)
                SELECT 'schedule',s.id,s.device_id,s.kind,u.display_name,s.last_done FROM schedules s
                LEFT JOIN users u ON u.id=s.assigned_to WHERE s.last_done IS NOT NULL""")
            db().execute("INSERT INTO activity_log(action,details) VALUES ('history_migrated','1')")
        for name,pwd,label,role in [('admin','Sawn@2026','مدير النظام','admin'),('tech','Tech@2026','أحمد','technician')]:
            db().execute('INSERT OR IGNORE INTO users(username,password_hash,display_name,role) VALUES (?,?,?,?)',(name,generate_password_hash(pwd),label,role))
        db().execute("UPDATE users SET display_name='أحمد' WHERE username='tech' AND display_name='أحمد - فني صيانة'")
        if not db().execute("SELECT 1 FROM activity_log WHERE action='capacity_setup'").fetchone():
            db().execute("UPDATE site_contact SET phone=COALESCE(NULLIF(phone,''),'12025550147'),email=COALESCE(NULLIF(email,''),'support@sawn.example') WHERE id=1")
            pending=db().execute("SELECT id,device_id,planned_date FROM tickets WHERE status!='مكتمل' AND (planned_date IS NULL OR planned_date>=?) ORDER BY COALESCE(planned_date,?),id",(date.today().isoformat(),date.today().isoformat())).fetchall()
            for row in pending:
                db().execute("UPDATE tickets SET planned_date=NULL WHERE id=?",(row['id'],))
            for row in pending:
                due=available_day(row['device_id'],row['planned_date'])
                db().execute("UPDATE tickets SET planned_date=? WHERE id=?",(due,row['id']))
            db().execute("INSERT INTO activity_log(action) VALUES ('capacity_setup')")
        db().commit()

@app.before_request
def load_user():
    g.user=db().execute("SELECT * FROM users WHERE id=? AND role IN ('admin','technician')",(session.get('uid',-1),)).fetchone()
    if 'csrf' not in session: session['csrf']=secrets.token_hex(24)
    if request.method=='POST' and request.endpoint!='login':
        if request.form.get('_csrf')!=session.get('csrf'):
            return 'Invalid CSRF token',400

    if g.user and request.endpoint in {'home','notifications','headline_json'}:
        pending = db().execute("""SELECT s.id,s.kind,s.due_date,d.asset_tag FROM schedules s JOIN devices d ON d.id=s.device_id
            WHERE s.due_date<=? AND (s.assigned_to=? OR (s.assigned_to IS NULL AND ?='admin'))
            AND NOT EXISTS(SELECT 1 FROM due_notices n WHERE n.schedule_id=s.id AND n.due_date=s.due_date AND n.recipient=?)""",
            (date.today().isoformat(),g.user['id'],g.user['role'],g.user['id'])).fetchall()
        for item in pending:
            inserted=db().execute('INSERT OR IGNORE INTO due_notices VALUES(?,?,?)',(item['id'],item['due_date'],g.user['id']))
            if inserted.rowcount:
                notify(g.user['id'],'حان موعد الصيانة',item['asset_tag']+' · '+item['kind'],'/maintenance')
        if pending:
            db().commit()

@app.after_request
def show_success(response):
    actions={'devices','device_detail','tickets','ticket_status','task_status','admin','identity','news','delete_announcement','maintenance',
             'maintenance_done','read_one','read_notifications','support','update_site_contact'}
    if request.method=='POST' and request.endpoint in actions and response.status_code==302 and g.get('user'):
        if not session.get('_flashes'):
            flash('تم الحفظ','success')
        if request.headers.get('X-Sawn-Save')=='1':
            ok=not any(kind=='error' for kind,_ in session.get('_flashes',[]))
            return jsonify(saved=ok,location=response.location)
    return response

@app.context_processor
def context():
    count=db().execute('SELECT count(*) FROM notifications WHERE user_id=? AND is_read=0',(g.user['id'],)).fetchone()[0] if g.user else 0
    return dict(csrf=session.get('csrf',''),current_user=g.user,unread=count,
                headline=latest_news() if g.user else None,
                contact=db().execute('SELECT * FROM site_contact WHERE id=1').fetchone())

def login_required(fn):
    @wraps(fn)
    def inner(*args,**kwargs):
        if not g.user:return redirect(url_for('login'))
        return fn(*args,**kwargs)
    return inner

def admin_required(fn):
    @wraps(fn)
    @login_required
    def inner(*args,**kwargs):
        if g.user['role']!='admin':return 'لا تملك الصلاحية / Access denied',403
        return fn(*args,**kwargs)
    return inner

def log(action,detail=''):
    db().execute('INSERT INTO activity_log(actor_id,action,details) VALUES (?,?,?)',(g.user['id'] if g.user else None,action,detail))

def notify(uid,title,body,link='/tasks'):
    db().execute('INSERT INTO notifications(user_id,title,message,link) VALUES (?,?,?,?)',(uid,title,body,link))

def latest_news():
    return db().execute('SELECT id,title_ar,title_en FROM announcements WHERE published=1 ORDER BY id DESC LIMIT 1').fetchone()

@app.get('/api/headline')
@login_required
def headline_json():
    row = latest_news()
    return jsonify(dict(row) if row else {})

@app.post('/admin/contact')
@admin_required
def update_site_contact():
    try:
        phone,email = contact_fields()
    except ValueError as error:
        flash(str(error),'error')
    else:
        db().execute('UPDATE site_contact SET phone=?,email=? WHERE id=1',(phone,email))
        db().commit()
    return redirect(url_for('admin'))

def technician_options():
    return db().execute("SELECT id,display_name FROM users WHERE role='technician' ORDER BY display_name").fetchall()

def selected_technician():
    people=technician_options()
    selected=request.form.get('technician_id',type=int)
    if selected is None and len(people)==1:
        return people[0]
    for person in people:
        if person['id']==selected:
            return person
    raise ValueError('اختر الفني المسؤول')

def planned_date():
    value=request.form.get('planned_date','').strip()
    return date.fromisoformat(value).isoformat() if value else None

def available_day(device_id, requested, exclude_id=0):
    day=max(date.today(),date.fromisoformat(requested) if requested else date.today())
    while True:
        occupied={r[0] for r in db().execute("""SELECT device_id FROM tickets WHERE planned_date=? AND id!=?
              UNION SELECT device_id FROM completed_work WHERE source='ticket' AND done_on=?""",
              (day.isoformat(),exclude_id,day.isoformat()))}
        if device_id in occupied or len(occupied)<5:
            return day.isoformat()
        day+=timedelta(days=1)

def create_ticket(device_id,tag,issue,person,planned):
    planned=available_day(device_id,planned)
    ticket=db().execute('INSERT INTO tickets(device_id,issue,technician,technician_id,planned_date) VALUES (?,?,?,?,?)',
                        (device_id,issue,person['display_name'],person['id'],planned))
    notify(person['id'],'بلاغ صيانة جديد',f"{tag} · {issue} · {planned}",f"/tickets#ticket-{ticket.lastrowid}")
    return ticket.lastrowid

def record_completion(source,source_id,device_id,work,technician,day,visible_to=None):
    db().execute('INSERT INTO completed_work(source,source_id,device_id,work,technician,done_on,visible_to) VALUES (?,?,?,?,?,?,?)',
                 (source,source_id,device_id,work,technician,day,visible_to))

def six_months_after(day):
    year=day.year+(day.month+5)//12
    month=(day.month+5)%12+1
    return date(year,month,min(day.day,calendar.monthrange(year,month)[1]))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        person=db().execute('SELECT * FROM users WHERE username=?',(request.form.get('username','').strip(),)).fetchone()
        if person and person['role'] in ('admin','technician') and check_password_hash(person['password_hash'],request.form.get('password','')):
            session.clear();session['uid']=person['id'];session['csrf']=secrets.token_hex(24)
            return redirect(url_for('home'))
        flash('بيانات الدخول غير صحيحة / Invalid credentials','error')
    return render_template('login.html')

@app.post('/logout')
@login_required
def logout():session.clear();return redirect(url_for('login'))

@app.route('/')
@login_required
def home():
    video = (ROOT/'static/media/intro.mp4').is_file()
    return render_template('home.html', video=video)

def contact_fields():
    phone = re.sub(r'[\s().\-\u200e\u200f\u061c]', '', request.form.get('whatsapp','').strip())
    phone = ''.join(str(int(c)) if c.isdecimal() else c for c in phone)
    if phone.startswith('00'):
        phone = phone[2:]
    elif phone.startswith('+'):
        phone = phone[1:]
    if re.fullmatch('[0-9]{8}', phone):
        phone = '968' + phone
    email = re.sub(r'[\u200e\u200f\u061c]', '', request.form.get('email','')).strip()
    if phone and not re.fullmatch('[1-9][0-9]{7,14}', phone):
        raise ValueError('تحقق من رقم واتساب ومفتاح الدولة')
    if email and (len(email)>254 or not re.fullmatch(r'[\w.+%-]+@[\w.-]+\.[\w-]+', email)):
        raise ValueError('تحقق من البريد الإلكتروني')
    return phone, email

@app.route('/devices',methods=['GET','POST'])
@login_required
def devices():
    if request.method=='POST':
        tag=request.form.get('asset_tag','').strip();name=request.form.get('name','').strip()
        if not tag or not name:flash('رقم الأصل واسم الجهاز مطلوبان','error')
        else:
            try:
                person=selected_technician()
                planned=planned_date()
                device=db().execute('INSERT INTO devices(asset_tag,name,model,department,whatsapp,email) VALUES (?,?,?,?,?,?)',(tag,name,request.form.get('model','').strip(),request.form.get('department','').strip(),*contact_fields()))
                create_ticket(device.lastrowid,tag,request.form.get('issue','').strip() or 'فحص الجهاز عند الاستلام',person,planned)
                log('device_created',tag)
                db().commit()
                flash('تم تسجيل الجهاز وإرسال البلاغ إلى '+person['display_name'],'success')
                return redirect(url_for('device_detail',id=device.lastrowid))
            except ValueError as error: flash(str(error),'error')
            except sqlite3.IntegrityError:flash('رقم الأصل مستخدم بالفعل','error')
        return redirect(url_for('devices'))
    rows=db().execute('SELECT * FROM devices ORDER BY id DESC').fetchall()
    return render_template('devices.html',rows=rows,people=technician_options())

@app.route('/devices/<int:id>',methods=['GET','POST'])
@login_required
def device_detail(id):
    dev=db().execute('SELECT * FROM devices WHERE id=?',(id,)).fetchone()
    if not dev:return 'Device not found',404
    if request.method=='POST':
        try:
            phone,email = contact_fields()
            db().execute('UPDATE devices SET whatsapp=?, email=? WHERE id=?',(phone,email,id))
            db().commit()
        except ValueError as error:
            flash(str(error),'error')
        return redirect(url_for('device_detail',id=id))
    subject = 'متابعة صيانة الجهاز ' + dev['asset_tag']
    body = 'مرحبًا، أود متابعة صيانة الجهاز ' + dev['asset_tag'] + ' (' + dev['name'] + ').'
    tickets=db().execute('SELECT * FROM tickets WHERE device_id=? ORDER BY id DESC',(id,)).fetchall()
    ready=bool(tickets) and all(ticket['status']=='مكتمل' for ticket in tickets)
    detail=[f"اسم الجهاز: {dev['name']}",f"رقم الجهاز: {dev['asset_tag']}"]
    if dev['model']:
        detail.append(f"الطراز: {dev['model']}")
    if tickets:
        detail.append(f"رقم آخر بلاغ: {tickets[0]['id']}")
    if ready:
        update='يسرّ فريق صَوْن إبلاغك بأن صيانة حاسوبك اكتملت، وأصبح الجهاز جاهزًا للاستلام.'
        action='يرجى التكرّم بمراجعة قسم الصيانة لاستلام جهازك، وذكر رقم الجهاز الوارد أعلاه ليسهل على الفني تسليمه لك. إذا رغبت في تنسيق وقت الاستلام، يمكنك الرد على هذه الرسالة.'
    else:
        update='نرسل إليك هذه الرسالة من نظام صَوْن لمتابعة طلب صيانة حاسوبك.'
        active=next((ticket for ticket in tickets if ticket['status']!='مكتمل'),None)
        if active:
            detail.append(f"حالة البلاغ رقم {active['id']}: {active['status']}")
            if active['planned_date']:
                detail.append(f"موعد الصيانة المخطّط: {active['planned_date']}")
        action='سيتواصل معك فريق الصيانة عند جاهزية الجهاز للاستلام. إذا كان لديك استفسار، يرجى الردّ مع ذكر رقم الجهاز لتسهيل متابعة طلبك.'
    message='\n\n'.join(['السلام عليكم ورحمة الله وبركاته،',update,'\n'.join(detail),action,'شكرًا لتعاونك،\nفريق صَوْن | نظام إدارة صيانة الحواسيب'])
    whatsapp='https://wa.me/'+dev['whatsapp']+'?'+urlencode({'text':message},quote_via=quote) if dev['whatsapp'] else None
    mail = 'mailto:' + quote(dev['email'],safe='@.+') + '?' + urlencode({'subject':subject,'body':body},quote_via=quote) if dev['email'] else None
    schedules=db().execute('SELECT * FROM schedules WHERE device_id=? ORDER BY due_date',(id,)).fetchall()
    webmail='https://mail.google.com/mail/?'+urlencode({'view':'cm','fs':'1','to':dev['email'],'su':subject,'body':body}) if mail else None
    return render_template('device_detail.html',dev=dev,tickets=tickets,schedules=schedules,whatsapp=whatsapp,mail=mail,webmail=webmail,ready=ready)

@app.route('/tickets',methods=['GET','POST'])
@login_required
def tickets():
    if request.method=='POST':
        device_id=request.form.get('device_id',type=int);issue=request.form.get('issue','').strip()
        if not db().execute('SELECT 1 FROM devices WHERE id=?',(device_id,)).fetchone() or not issue:flash('حدد الجهاز ووصف المشكلة','error')
        else:
            try:
                person=selected_technician()
                db().execute('BEGIN IMMEDIATE')
                tag=db().execute('SELECT asset_tag FROM devices WHERE id=?',(device_id,)).fetchone()[0]
                create_ticket(device_id,tag,issue,person,planned_date())
                log('ticket_created',issue[:80]);db().commit()
            except ValueError as error:
                flash(str(error),'error')
        return redirect(url_for('tickets'))
    rows=db().execute('SELECT t.*,d.asset_tag,d.name device_name FROM tickets t JOIN devices d ON d.id=t.device_id ORDER BY t.id DESC').fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    return render_template('tickets.html',rows=rows,devs=devs,statuses=STATUSES,people=technician_options())

@app.post('/tickets/<int:id>/status')
@login_required
def ticket_status(id):
    status=request.form.get('status','')
    if status not in STATUSES:return 'Invalid status',400
    db().execute('BEGIN IMMEDIATE')
    row=db().execute('SELECT * FROM tickets WHERE id=?',(id,)).fetchone()
    if not row:return 'Ticket not found',404
    if g.user['role']=='employee':return 'Access denied',403
    try:
        planned = planned_date() if 'planned_date' in request.form else row['planned_date']
    except ValueError:
        return 'Invalid date',400
    if status=='مكتمل' and row['status']!=status:
        today=date.today().isoformat()
        completed={r[0] for r in db().execute("SELECT DISTINCT device_id FROM completed_work WHERE source='ticket' AND done_on=?",(today,))}
        if (len(completed)>=5 and row['device_id'] not in completed) or available_day(row['device_id'],today,id)!=today:
            flash('اكتمل جدول اليوم لخمسة أجهزة. تابع في الموعد المتاح.','error')
            return redirect(url_for('tickets'))
    if status!='مكتمل' and (planned!=row['planned_date'] or not planned or row['status']=='مكتمل'):
        planned=available_day(row['device_id'],planned,id)
    db().execute('UPDATE tickets SET status=?,planned_date=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,planned,id))
    if status=='مكتمل' and row['status']!=status:
        record_completion('ticket',id,row['device_id'],row['issue'],g.user['display_name'],date.today().isoformat())
        flash('تم إغلاق التذكرة','repair_done')
    log('ticket_updated',str(id));db().commit()
    return redirect(url_for('tickets'))

@app.route('/technicians')
@login_required
def technicians():
    people=db().execute("SELECT * FROM users WHERE role='technician' ORDER BY id").fetchall()
    return render_template('technicians.html',people=people)

@app.route('/tasks')
@login_required
def tasks():
    q='''SELECT t.*,u.display_name assignee,d.asset_tag FROM tasks t JOIN users u ON u.id=t.assigned_to LEFT JOIN devices d ON d.id=t.device_id'''
    if g.user['role']=='admin':rows=db().execute(q+' ORDER BY t.id DESC').fetchall()
    else:rows=db().execute(q+' WHERE t.assigned_to=? ORDER BY t.id DESC',(g.user['id'],)).fetchall()
    return render_template('tasks.html',rows=rows)

@app.route('/admin',methods=['GET','POST'])
@admin_required
def admin():
    if request.method=='POST':
        title=request.form.get('title','').strip();target=request.form.get('assigned_to',type=int)
        person=db().execute('SELECT * FROM users WHERE id=?',(target,)).fetchone()
        device_id=request.form.get('device_id',type=int) or None
        if not title or not person:flash('يرجى كتابة المهمة واختيار المستخدم','error')
        else:
            db().execute('''INSERT INTO tasks(title,description,device_id,assigned_to,assigned_by,priority,due_date) VALUES (?,?,?,?,?,?,?)''',(title,request.form.get('description','').strip(),device_id,target,g.user['id'],request.form.get('priority','normal'),request.form.get('due_date') or None))
            notify(target,'مهمة جديدة من الإدارة',title,'/tasks');log('task_assigned',title);db().commit();flash('تم إرسال المهمة والإشعار','success')
        return redirect(url_for('admin'))
    users=db().execute("SELECT * FROM users WHERE role='technician'").fetchall()
    g.identities=db().execute("SELECT id,display_name,role FROM users WHERE role IN ('admin','technician') ORDER BY id").fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    return render_template('admin.html',users=users,devs=devs)

@app.post('/tasks/<int:id>/status')
@login_required
def task_status(id):
    db().execute('BEGIN IMMEDIATE')
    row=db().execute('SELECT * FROM tasks WHERE id=?',(id,)).fetchone()
    if not row:return 'Not found',404
    if row['assigned_to']!=g.user['id'] and g.user['role']!='admin':return 'Access denied',403
    status=request.form.get('status','')
    if status not in ('pending','in_progress','completed'):return 'Invalid status',400
    db().execute('UPDATE tasks SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,id))
    if status=='completed' and row['status']!=status:
        record_completion('task',id,row['device_id'],row['title'],g.user['display_name'],date.today().isoformat(),row['assigned_to'])
    if row['assigned_to']!=row['assigned_by']:notify(row['assigned_by'],'تحديث حالة المهمة',f"{row['title']} — {status}",'/tasks')
    db().commit();return redirect(url_for('tasks'))

@app.post('/notifications/preference')
@login_required
def notification_preference():
    enabled = request.form.get('enabled') == '1'
    db().execute('UPDATE users SET alerts_on=? WHERE id=?',(int(enabled),g.user['id']))
    db().commit()
    return jsonify(enabled=enabled)

@app.post('/admin/identity')
@admin_required
def identity():
    name=request.form.get('display_name','').strip()
    rank=''
    if not name or len(name)>80 or len(rank)>60:
        return 'Invalid identity',400
    db().execute('UPDATE users SET display_name=?,rank=? WHERE id=?',(name,rank,request.form.get('uid',type=int)))
    db().commit()
    return redirect(url_for('admin'))

@app.route('/notifications')
@login_required
def notifications():
    rows=db().execute('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC',(g.user['id'],)).fetchall()
    return render_template('notifications.html',rows=rows)

@app.post('/notifications/<int:id>/read')
@login_required
def read_one(id):
    result=db().execute('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?',(id,g.user['id']))
    if not result.rowcount:
        return 'Not found',404
    db().commit()
    return redirect(url_for('notifications'))

@app.post('/notifications/read')
@login_required
def read_notifications():
    db().execute('UPDATE notifications SET is_read=1 WHERE user_id=?',(g.user['id'],));db().commit();return redirect(url_for('notifications'))

@app.route('/news',methods=['GET','POST'])
@login_required
def news():
    if request.method=='POST':
        if g.user['role']!='admin':return 'Access denied',403
        title=request.form.get('title_ar','').strip()
        if not title:
            flash('أدخل عنوان الإعلان بالعربية','error')
            return redirect(url_for('news'))
        db().execute('''INSERT INTO announcements(title_ar,title_en,body_ar,body_en,category,event_date)
                        VALUES (?,?,?,?,?,?)''', (title, request.form.get('title_en','').strip(),
                        request.form.get('body_ar',''), request.form.get('body_en',''),
                        request.form.get('category','news'), request.form.get('event_date') or None))
        db().commit()
        return redirect(url_for('news'))
    rows=db().execute('SELECT * FROM announcements WHERE published=1 ORDER BY id DESC').fetchall()
    return render_template('news.html',rows=rows)

@app.post('/news/<int:id>/delete')
@admin_required
def delete_announcement(id):
    db().execute('UPDATE announcements SET published=0 WHERE id=? AND published=1',(id,))
    db().commit()
    return redirect(url_for('news'))

@app.route('/maintenance',methods=['GET','POST'])
@login_required
def maintenance():
    if request.method=='POST':
        if g.user['role']!='admin':return 'Access denied',403
        dev=request.form.get('device_id',type=int);kind=request.form.get('kind','').strip();due=request.form.get('due_date')
        thermal=request.form.get('cycle')=='thermal'
        if thermal:
            kind='مراجعة المعجون الحراري'
            due=six_months_after(date.today()).isoformat()
        if not dev or not kind or not due:
            flash('أكمل بيانات الجدولة','error')
        else:
            entry=db().execute('INSERT INTO schedules(device_id,kind,due_date,interval_days,assigned_to,interval_months,last_done) VALUES (?,?,?,?,?,?,?)',
                (dev,kind,due,max(1,request.form.get('interval_days',type=int) or 90),request.form.get('assigned_to',type=int) or None,
                 6 if thermal else 0,date.today().isoformat() if thermal else None))
            if thermal:
                record_completion('schedule',entry.lastrowid,dev,'تبديل المعجون الحراري',g.user['display_name'],date.today().isoformat())
            db().commit()
        return redirect(url_for('maintenance'))
    rows=db().execute('SELECT s.*,d.name device_name,d.asset_tag FROM schedules s JOIN devices d ON d.id=s.device_id ORDER BY s.due_date').fetchall()
    devs=db().execute('SELECT * FROM devices ORDER BY asset_tag').fetchall()
    users=db().execute("SELECT * FROM users WHERE role='technician'").fetchall()
    return render_template('maintenance.html',rows=rows,devs=devs,users=users,today=date.today().isoformat())

@app.post('/maintenance/<int:id>/done')
@login_required
def maintenance_done(id):
    db().execute('BEGIN IMMEDIATE')
    row=db().execute('SELECT * FROM schedules WHERE id=?',(id,)).fetchone()
    if not row:return 'Not found',404
    if g.user['role']!='admin' and row['assigned_to']!=g.user['id']:return 'Access denied',403
    today=date.today()
    if row['last_done']==today.isoformat():
        return redirect(url_for('maintenance'))
    next_due=six_months_after(today) if row['interval_months']==6 else today+timedelta(days=row['interval_days'])
    record_completion('schedule',id,row['device_id'],row['kind'],g.user['display_name'],today.isoformat())
    db().execute('UPDATE schedules SET last_done=?,due_date=? WHERE id=?',(today.isoformat(),next_due.isoformat(),id))
    log('preventive_maintenance_done',str(id));db().commit();return redirect(url_for('maintenance'))

@app.route('/reports')
@login_required
def reports():
    today=date.today()
    monday=today-timedelta(days=today.weekday())
    choices={'previous':-1,'current':0,'next':1}
    week=request.args.get('week','current')
    begin=monday+timedelta(weeks=choices.get(week,0))
    if request.args.get('start'):
        try:
            begin=date.fromisoformat(request.args['start'])
        except ValueError:
            return 'Invalid date',400
    end=begin+timedelta(days=6)
    params={'start':begin.isoformat(),'end':end.isoformat(),'admin':int(g.user['role']=='admin'),'uid':g.user['id']}
    done=db().execute("""SELECT w.done_on day,d.asset_tag,w.work,w.technician FROM completed_work w
        LEFT JOIN devices d ON d.id=w.device_id WHERE w.done_on BETWEEN :start AND :end
        AND (:admin OR w.visible_to IS NULL OR w.visible_to=:uid) ORDER BY day,w.id""",params).fetchall()
    plan=db().execute("""SELECT t.planned_date day,d.asset_tag,t.issue work,t.technician FROM tickets t
        JOIN devices d ON d.id=t.device_id WHERE t.status!='مكتمل' AND t.planned_date BETWEEN :start AND :end
        UNION ALL SELECT t.due_date,d.asset_tag,t.title,u.display_name FROM tasks t JOIN users u ON t.assigned_to=u.id
        LEFT JOIN devices d ON d.id=t.device_id WHERE t.status!='completed' AND t.due_date BETWEEN :start AND :end
        AND (:admin OR t.assigned_to=:uid)
        UNION ALL SELECT s.due_date,d.asset_tag,s.kind,u.display_name FROM schedules s JOIN devices d ON d.id=s.device_id
        LEFT JOIN users u ON u.id=s.assigned_to WHERE s.due_date BETWEEN :start AND :end ORDER BY day,asset_tag""",params).fetchall()
    return render_template('reports.html',start=begin,end=end,done=done,plan=plan,week=week)

@app.route('/support',methods=['GET','POST'])
@login_required
def support():
    if request.method=='POST':
        subject=request.form.get('subject','').strip();message=request.form.get('message','').strip()
        if subject and message:
            db().execute('INSERT INTO support_requests(user_id,subject,message) VALUES (?,?,?)',(g.user['id'],subject,message));db().commit();flash('تم إرسال طلب الدعم','success')
        else:flash('املأ جميع الحقول','error')
        return redirect(url_for('support'))
    return render_template('support.html')

@app.post('/assistant/ask')
@login_required
def assistant_ask():
    model=os.environ.get('SAWN_LOCAL_MODEL')
    if not model:
        return jsonify(available=False)
    question=request.form.get('question','').strip()[:1800]
    if not question:
        return jsonify(available=False)
    body={'model':model,'stream':False,'messages':[
        {'role':'system','content':'You are SAWN help. Reply briefly in the question language. SAWN registers devices, assigns repair tickets, schedules five devices per day and prints weekly reports. You cannot read or change records.'},
        {'role':'user','content':question}]}
    try:
        query=Request('http://127.0.0.1:11434/api/chat',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
        with urlopen(query,timeout=25) as result:
            return jsonify(answer=json.load(result)['message']['content'])
    except (URLError,TimeoutError,ValueError,KeyError):
        return jsonify(available=False)

@app.route('/api/search')
@login_required
def search():
    q=request.args.get('q','').strip()[:100]
    if len(q)<2:return jsonify([])
    pattern='%'+q.replace('%','\\%').replace('_','\\_')+'%'
    devices=db().execute("SELECT id,asset_tag,name FROM devices WHERE asset_tag LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' LIMIT 6",(pattern,pattern)).fetchall()
    tickets=db().execute("SELECT id,issue FROM tickets WHERE issue LIKE ? ESCAPE '\\' OR cast(id as text) LIKE ? ESCAPE '\\' LIMIT 5",(pattern,pattern)).fetchall()
    return jsonify([{'title':r['asset_tag']+' · '+r['name'],'url':'/devices/'+str(r['id']),'type':'device'} for r in devices]+[{'title':'#'+str(r['id'])+' · '+r['issue'][:55],'url':'/tickets','type':'ticket'} for r in tickets])

setup()
if __name__=='__main__':app.run(debug=True)
