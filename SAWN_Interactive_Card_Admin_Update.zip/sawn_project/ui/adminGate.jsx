import { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import CodeSlots from './CodeSlots';

const networkError = {
  ar: 'تعذّر التحقق من الرمز. حاول مرة أخرى.',
  en: 'Could not verify the code. Try again.',
};

function AdminCode({ form, container }) {
  const [locale, setLocale] = useState(document.documentElement.lang);
  const [status, setStatus] = useState('idle');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState(null);
  const operation = useRef(null);
  const navigation = useRef(null);

  useEffect(() => {
    const observer = new MutationObserver(() => setLocale(document.documentElement.lang));
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    return () => {
      observer.disconnect();
      operation.current?.abort();
      clearTimeout(navigation.current);
    };
  }, []);

  useEffect(() => {
    if (status === 'error' && !pending) container.querySelector('input')?.focus();
  }, [status, pending, container]);

  async function complete(code) {
    if (operation.current) return;
    const controller = new AbortController();
    operation.current = controller;
    setPending(true);
    const body = new URLSearchParams({ _csrf: form.elements._csrf.value, pin: code });
    try {
      const response = await fetch(form.action, {
        method: 'POST', body, signal: controller.signal, headers: { Accept: 'application/json' }
      });
      const result = await response.json();
      if (controller.signal.aborted) return;
      if (!response.ok || !result.location) {
        setError(result.error ?? networkError);
        setStatus('error');
        return;
      }
      setStatus('success');
      form.dataset.verified = '';
      document.dispatchEvent(new CustomEvent('sawn:confirmed', { detail: { inline: true } }));
      const delay = matchMedia('(prefers-reduced-motion: reduce)').matches ? 350 : 1100;
      navigation.current = setTimeout(() => location.assign(result.location), delay);
    } catch {
      if (!controller.signal.aborted) {
        setError(networkError);
        setStatus('error');
      }
    } finally {
      if (!controller.signal.aborted) {
        operation.current = null;
        setPending(false);
      }
    }
  }

  return <>
    <CodeSlots
      length={5}
      locale={locale}
      status={status}
      disabled={pending}
      mask
      autoFocus
      onChange={code => {
        if (code && status === 'error') {
          setError(null);
          setStatus('idle');
        }
      }}
      onComplete={complete}
      ariaLabel={locale === 'ar' ? 'رمز لوحة الأدمن' : 'Admin panel code'}
      slotSize={39}
      gap={8}
      accentColor="#17734d"
      slotColor="#172f4b"
      digitColor="#fff"
    />
    <p className="adminAccessFeedback" role="status">{error?.[locale]}</p>
  </>;
}

export function setupAdminGate() {
  const dialog = document.querySelector('#adminAccessDialog');
  const form = document.querySelector('.adminAccessForm');
  const container = form?.querySelector('.adminCodeSlots');
  let root;
  form?.addEventListener('submit', event => {
    if (root) event.preventDefault();
  });
  function mount() {
    if (!container || root) return;
    const fallback = form.querySelector('.adminAccessFallback');
    fallback.hidden = true;
    form.elements.pin.disabled = true;
    root = createRoot(container);
    root.render(<AdminCode form={form} container={container} />);
  }

  if (!dialog) {
    mount();
    return;
  }
  const openLink = document.querySelector('[data-admin-access]');
  openLink?.addEventListener('click', event => {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    dialog.showModal();
    mount();
  });
  dialog.addEventListener('close', () => {
    root?.unmount();
    root = null;
    if (form) delete form.dataset.verified;
  });
}
