import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import JellyRadio from './JellyRadio';
import PromptBar from './PromptBar';
import BellToggle from './BellToggle';
import Lanyard from './Lanyard';
import {setupAdminGate} from './adminGate';

const byId = id => document.getElementById(id);
const english = () => document.documentElement.lang === 'en';
const languageObserver = new MutationObserver(() => renderWidgets());
const mounts = new Map();
function mount(id, component) {
  const el = byId(id);
  if (!el) return;
  if (!mounts.has(el)) mounts.set(el,createRoot(el));
  mounts.get(el).render(component);
}
const nav = byId('jellyNav');
const links = nav ? Array.from(nav.querySelectorAll('a'), a => ({
  value:a.dataset.endpoint, url:a.href, ar:a.textContent, icon:a.dataset.icon
})) : [];
const enLabels = {home:'Home',devices:'Devices',tickets:'Tickets',technicians:'Technicians',reports:'Reports',maintenance:'Preventive care',news:'News'};
function Bell({el,en}) {
  const [on,setOn] = useState(el.dataset.enabled === '1');
  const [pending,setPending] = useState(false);
  const [error,setError] = useState('');
  async function change(next) {
    setPending(true);setOn(next);setError('');
    try {
      const response = await fetch('/notifications/preference',{method:'POST',body:new URLSearchParams({_csrf:el.dataset.token,enabled:next?'1':'0'})});
      if (!response.ok || (await response.json()).enabled !== next) throw Error();
      document.dispatchEvent(new Event('sawn:confirmed'));
      const link=document.querySelector('.notifyIcon');
      link.querySelector('b')?.remove();
      if(next && Number(el.dataset.count)>0) {
        const badge=document.createElement('b');badge.textContent=el.dataset.count;link.append(badge);
      }
    } catch {
      setOn(!next);setError(en?'Could not save. Try again.':'تعذّر الحفظ. حاول مرة أخرى.');
    } finally {setPending(false);}
  }
  return <><BellToggle pressed={on} disabled={pending} onChange={change} badge count={Number(el.dataset.count)} offLabel={en?'Enable alerts':'فعّل الإشعارات'} onLabel={en?'Alerts enabled':'الإشعارات مفعّلة'} onBackground="#12294b" onColor="white" background="#e8eef2" color="#12294b"/><span role="status">{error}</span></>;
}
function renderWidgets() {
  const en=english();
  if(nav) mount('jellyNav',<JellyRadio ariaLabel={en?'Sections':'الأقسام'} items={links.map(l=>({...l,label:en?enLabels[l.value]:l.ar}))} value={nav.dataset.endpoint} onChange={value=>location.assign(links.find(l=>l.value===value).url)} gap={6} swell={.045} barge={1} chipColor="#edf1f3" activeColor="#152b4e" textColor="#152b4e" activeTextColor="#fff"/>);
  if(byId('promptBar')) {
    const topics=en?['device','ticket','report']:['جهاز','بلاغ','تقرير'];
    mount('promptBar',<PromptBar placeholder={en?'How can I help?':'كيف أقدر أساعدك؟'} models={[]} efforts={[]} sources={topics.map(name=>({key:name,name}))} commands={[]} width="100%" background="#172e4e" onSend={text=>document.dispatchEvent(new CustomEvent('sawn:ask',{detail:text}))}/>);
    byId('chatForm').hidden=true;
  }
  if(byId('bellToggle')) mount('bellToggle',<Bell el={byId('bellToggle')} en={en}/>);
}
renderWidgets();
setupAdminGate();
languageObserver.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
function showPass(id) {
  const target=byId(id);
  if(!target || matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  const canvas=document.createElement('canvas');canvas.width=768;canvas.height=480;
  const ctx=canvas.getContext('2d');ctx.fillStyle='#162e50';ctx.fillRect(0,0,768,480);
  ctx.textAlign='center';ctx.fillStyle='#eec666';ctx.font='bold 62px sans-serif';ctx.fillText('صَوْن',384,112);
  ctx.fillStyle='white';ctx.font='bold 66px sans-serif';ctx.fillText(byId('identityName').textContent,384,245,685);
  ctx.font='52px sans-serif';ctx.fillText(byId('identityRank').textContent,384,345,685);
  mount(id,<Lanyard orientation="landscape" size={.7} frontImage={canvas.toDataURL()} strapLength={.15} breeze={.12} strapColor="#17365a" finish="matte"/>);
}
showPass('lanyard');
const bigPass = byId('bigIdentity');
if(bigPass){
  new MutationObserver(()=>{
    if(bigPass.open)showPass('largeLanyard');
    else {const target=byId('largeLanyard');mounts.get(target)?.unmount();mounts.delete(target);}
  }).observe(bigPass,{attributes:true,attributeFilter:['open']});
  let down;
  const stage=byId('lanyard');
  stage.addEventListener('pointerdown', e=>{down=[e.clientX,e.clientY];});
  stage.addEventListener('pointerup',e=>{
    if(down && Math.hypot(e.clientX-down[0],e.clientY-down[1])<5 && !bigPass.open)bigPass.showModal();
    down=null;
  });
  new MutationObserver(()=>{showPass('lanyard');if(bigPass.open)showPass('largeLanyard');})
    .observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
}
