@echo off
setlocal DisableDelayedExpansion

pushd "%~dp0sawn_project" 2>nul || goto missing_project
if not exist "requirements.txt" goto incomplete_archive
if not exist "app.py" goto incomplete_archive

set "SAWN_PYTHON=%CD%\.venv\Scripts\python.exe"
if not exist "%SAWN_PYTHON%" (
    where py >nul 2>nul
    if errorlevel 1 (
        python -m venv ".venv" || goto startup_failed
    ) else (
        py -3 -m venv ".venv" || goto startup_failed
    )
)

"%SAWN_PYTHON%" -m pip install -r "%CD%\requirements.txt" || goto startup_failed
if not defined SAWN_ADMIN_PIN set /p "SAWN_ADMIN_PIN=Enter your five-digit admin panel code: "
echo.
echo Open http://127.0.0.1:5000 in your browser once the server starts.
"%SAWN_PYTHON%" "%CD%\app.py" || goto startup_failed

popd
exit /b 0

:incomplete_archive
popd
:missing_project
echo Extract all files from the SAWN ZIP, then run Start_SAWN.cmd from the extracted folder.
pause
exit /b 1

:startup_failed
popd
echo SAWN could not start. See the error above.
pause
exit /b 1
