const cycle = document.querySelector('#cycle');
if (cycle) {
  const sync = () => {
    const custom = cycle.value === 'custom';
    document.querySelector('#customCycle').hidden = !custom;
    document.querySelectorAll('#customCycle input,#customCycle select').forEach(el => el.disabled = !custom);
  };
  cycle.addEventListener('change', sync);
  sync();
}
const headline = document.querySelector('#headline');
if (headline) {
  const track = headline.querySelector('.tickerTrack');
  const label = track.querySelector('span');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  let animation;

  function syncPlayback() {
    if (!animation) return;
    if (headline.matches(':hover, :focus-visible')) animation.pause();
    else animation.play();
  }

  function showHeadlineInOrder() {
    animation?.cancel();
    animation = null;
    const firstWord = label.textContent.match(/^\s*\S+/u)?.[0];
    if (headline.hidden || reducedMotion.matches || !track.clientWidth || !firstWord) return;

    const range = document.createRange();
    range.setStart(label.firstChild, 0);
    range.setEnd(label.firstChild, firstWord.length);
    const width = label.getBoundingClientRect().width;
    const visibleWidth = Math.min(width, track.clientWidth);
    const firstWidth = Math.min(visibleWidth, range.getBoundingClientRect().width);
    const overflow = Math.max(0, width - visibleWidth);
    const rtl = getComputedStyle(label).direction === 'rtl';
    const clip = hidden => rtl ? `inset(0 0 0 ${hidden}px)` : `inset(0 ${hidden}px 0 0)`;
    const secondsAtWord = 0.85;
    const revealEnd = secondsAtWord + Math.max(1.2, (visibleWidth - firstWidth) / 46);
    const panEnd = revealEnd + overflow / 42;
    const duration = panEnd + 3.5;
    const begin = {clipPath: clip(width - firstWidth), transform: 'translateX(0px)'};
    const finish = {clipPath: clip(0), transform: `translateX(${rtl ? overflow : -overflow}px)`};
    const frames = [
      {...begin, offset: 0},
      {...begin, offset: secondsAtWord / duration},
      {clipPath: clip(overflow), transform: 'translateX(0px)', offset: revealEnd / duration},
      {...finish, offset: 1},
    ];
    if (overflow) frames.splice(3, 0, {...finish, offset: panEnd / duration});
    animation = label.animate(frames, {duration: duration * 1000, iterations: Infinity});
    syncPlayback();
  }
  const tickerSize = new ResizeObserver(showHeadlineInOrder);
  tickerSize.observe(track);
  tickerSize.observe(label);
  new MutationObserver(showHeadlineInOrder).observe(label, {childList:true, characterData:true, subtree:true});
  reducedMotion.addEventListener('change', showHeadlineInOrder);
  for (const event of ['pointerenter','pointerleave','focus','blur']) {
    headline.addEventListener(event, syncPlayback);
  }

  async function refreshHeadline() {
    if (document.hidden) return;
    try {
      const res = await fetch('/api/headline', {cache:'no-store'});
      if (!res.ok) return;
      const item = await res.json();
      headline.hidden = !item.id;
      label.dataset.ar = item.title_ar || '';
      label.dataset.en = item.title_en || label.dataset.ar;
      const text = label.dataset[document.documentElement.lang] || label.dataset.ar;
      if(label.textContent !== text) label.textContent = text;
    } catch {}
  }
  setInterval(refreshHeadline, 5000);
  document.addEventListener('visibilitychange', refreshHeadline);
}

const passDialog = document.querySelector('#bigIdentity');
if (passDialog) {
  const stage = passDialog.querySelector('.largeStage');
  const controls = passDialog.querySelectorAll('[data-pass-step]');
  const minZoom = 60;
  const maxZoom = 100;
  let zoom = 90;
  controls.forEach(button => button.addEventListener('click', () => {
    zoom = Math.max(minZoom, Math.min(maxZoom, zoom + Number(button.dataset.passStep)));
    stage.style.setProperty('--pass-zoom', `${zoom}%`);
    controls[0].disabled = zoom === minZoom;
    controls[1].disabled = zoom === maxZoom;
  }));
}

const tutorialLaunch = document.querySelector('#homeTutorialLaunch');
const tutorialDialog = document.querySelector('#homeTutorial');
if (tutorialLaunch && tutorialDialog?.showModal) {
  const video = tutorialDialog.querySelector('video');
  tutorialLaunch.addEventListener('click', event => {
    if (event.button || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    tutorialDialog.showModal();
    video.play().catch(() => {});
  });
  tutorialDialog.addEventListener('close', () => video.pause());
}

const peek = document.querySelector('#peekRange');
if (peek) {
  const first = new Date();
  first.setDate(first.getDate() - (first.getDay()+6)%7);
  function iso(d) {return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}
  function update(delta) {
    first.setDate(first.getDate()+delta);
    const end=new Date(first);
    end.setDate(end.getDate()+6);
    peek.textContent=iso(first)+' — '+iso(end);
    document.querySelector('#peekReport').href='/reports?start='+iso(first);
  }
  document.querySelector('#weekBack').onclick=()=>update(-7);
  document.querySelector('#weekForward').onclick=()=>update(7);
  update(0);
}
const themeSwitch=document.querySelector('#themeToggle');
function showTheme(){
  if(!themeSwitch)return;
  const dark=document.documentElement.dataset.theme==='dark';
  themeSwitch.textContent=dark?'☀':'☾';
  themeSwitch.setAttribute('aria-pressed',String(dark));
  themeSwitch.title=document.documentElement.lang==='en'?'Light / dark theme':'الوضع الليلي / النهاري';
}
showTheme();
themeSwitch?.addEventListener('click',()=>{
  const theme=document.documentElement.dataset.theme==='dark'?'light':'dark';
  document.documentElement.dataset.theme=theme;
  localStorage.setItem('sawnTheme',theme);showTheme();
});
document.querySelector('#botToggle')?.addEventListener('click',e=>{
  const btn=e.currentTarget;btn.classList.remove('wave');void btn.offsetWidth;btn.classList.add('wave');
  btn.setAttribute('aria-expanded',String(!document.querySelector('#chatPanel').hidden));
});
let audio;
function armTick(){
  try{audio??=new AudioContext();audio.resume().catch(()=>{});}catch{}
}
function playTick(){
  if(!audio||audio.state!=='running')return;
  const tone=audio.createOscillator(),gain=audio.createGain(),now=audio.currentTime;
  tone.frequency.setValueAtTime(1040,now);tone.frequency.exponentialRampToValueAtTime(760,now+.07);
  gain.gain.setValueAtTime(.07,now);gain.gain.exponentialRampToValueAtTime(.001,now+.09);
  tone.connect(gain).connect(audio.destination);tone.start(now);tone.stop(now+.1);
}
document.addEventListener('pointerdown',armTick,{once:true});
document.addEventListener('keydown',armTick,{once:true});
document.addEventListener('submit',async event=>{
  const form=event.target;
  if(form.method.toLowerCase()!=='post'||!form.querySelector('[name="_csrf"]')||form.action.endsWith('/logout')||form.matches('.adminAccessForm'))return;
  event.preventDefault();if(form.dataset.saving)return;form.dataset.saving='1';
  armTick();
  try{
    const res=await fetch(form.action,{method:'POST',headers:{'X-Sawn-Save':'1'},body:new FormData(form)});
    if(res.redirected){location.assign(res.url);return;}
    if(!res.ok)throw Error();
    const result=await res.json();
    if(result.saved){playTick();await new Promise(resolve=>setTimeout(resolve,120));}
    location.assign(result.location);
  }catch{alert(document.documentElement.lang==='en'?'Could not confirm the save. Refresh to check.':'تعذّر تأكيد الحفظ. حدّث الصفحة للتحقق.');delete form.dataset.saving;}
});
// Localize dynamic week labels and status options while preserving form values.
const scheduleLabels={'الأسبوع الماضي':'Previous week','هذا الأسبوع':'This week','الأسبوع القادم':'Next week','الأعمال المنجزة':'Completed work','خطة الإصلاح والصيانة':'Planned repairs','جديد':'New','قيد الصيانة':'In repair','مكتمل':'Completed','مدير النظام':'System administrator','فني الصيانة':'Maintenance technician','تم الحفظ':'Saved'};
for(const el of document.querySelectorAll('.reportTools nav a,.reportBlock h2,select[name=status] option,.flash,#bigIdentity small,.drawerUser small')){
  for(const node of [...el.childNodes].filter(n=>n.nodeType===3)){
    const ar=node.textContent.trim(),en=scheduleLabels[ar];if(!en)continue;
    if(el.tagName==='OPTION'){el.value=el.value;el.dataset.ar=ar;el.dataset.en=en;el.classList.add('multilang');el.textContent=document.documentElement.lang==='en'?en:ar;break;}
    const span=document.createElement('span');span.className='multilang';span.dataset.ar=ar;span.dataset.en=en;span.textContent=document.documentElement.lang==='en'?en:ar;node.replaceWith(span);
  }
}
document.addEventListener('sawn:confirmed',event=>{
  playTick();
  if (event.detail?.inline) return;
  const marker=document.createElement('span');
  marker.className='savedMark';marker.setAttribute('role','status');marker.textContent='✓';
  document.body.append(marker);setTimeout(()=>marker.remove(),1100);
});
document.querySelector('#helpFromFooter')?.addEventListener('click',()=>{
 const panel=document.querySelector('#chatPanel');
 if(panel.hidden)document.querySelector('#botToggle').click();
 panel.querySelector('textarea,input')?.focus();
});
document.querySelector('.logoDemo')?.addEventListener('click',event=>{
 const mark=event.currentTarget.querySelector('.wordmark');mark.classList.add('active');
 window.setTimeout(()=>mark.classList.remove('active'),550);
});
