"""Populate the review build with fictional data once per database."""
from datetime import date, datetime, time, timedelta
from secrets import token_urlsafe

from werkzeug.security import generate_password_hash

TECHNICIANS = (
    ('zakaria', 'زكريا'), ('maryam', 'مريم'), ('khalid', 'خالد'),
    ('fatima', 'فاطمة'), ('yousef', 'يوسف'), ('aisha', 'عائشة'),
    ('hamad', 'حمد'), ('noor', 'نور'), ('rashid', 'راشد'),
    ('maha', 'مها'), ('ali', 'علي'),
)
DEPARTMENTS = (
    'تقنية المعلومات', 'شؤون الموظفين', 'المالية',
    'خدمة المستفيدين', 'التدريب', 'المخازن',
)
EQUIPMENT = (
    ('حاسوب مكتبي', 'Dell OptiPlex 7010', ('ارتفاع حرارة المعالج', 'بطء عند تسجيل الدخول')),
    ('حاسوب محمول', 'Lenovo ThinkPad E14', ('البطارية تنفد بسرعة', 'انقطاع الاتصال بالشبكة اللاسلكية')),
    ('حاسوب مكتبي', 'HP ProDesk 400', ('انقطاع عرض الشاشة', 'ضجيج من مروحة التبريد')),
    ('شاشة مكتبية', 'Dell P2422H', ('وميض متقطع في الشاشة', 'مراجعة منفذ العرض والكابل')),
    ('طابعة شبكية', 'HP LaserJet Pro 4001', ('انحشار الورق في درج التغذية', 'ظهور خطوط باهتة عند الطباعة')),
    ('حاسوب محمول', 'Dell Latitude 5440', ('منفذ الشحن غير ثابت', 'لوحة اللمس لا تستجيب أحيانًا')),
    ('محطة عمل', 'Lenovo ThinkStation P3', ('تنبيه امتلاء مساحة التخزين', 'اختبار استقرار الجهاز بعد تحديث التعريفات')),
    ('ماسح ضوئي', 'Epson DS-530 II', ('تعذّر سحب المستندات', 'المسح يتوقف بعد الصفحة الأولى')),
)
MAINTENANCE_TYPES = (
    'تنظيف الجهاز والمراوح', 'فحص المعجون الحراري',
    'فحص القرص الصلب', 'فحص نظام التبريد',
)
TASK_TITLES = (
    'فحص حرارة المعالج', 'مراجعة التوصيلات في غرفة التدريب',
    'التحقق من النسخة الاحتياطية', 'اختبار الجهاز بعد الصيانة',
    'جرد ملحقات الأجهزة', 'تحديث تعريفات أجهزة العمل',
)
ANNOUNCEMENTS = (
    ('تحديث سجل أصول الأجهزة', 'Update device inventory',
     'راجع رقم الأصل والقسم عند تسجيل أي جهاز جديد.',
     'Confirm the asset tag and department when registering a device.', 'news'),
    ('ورشة العناية بالأجهزة والمراوح', 'Device and fan maintenance workshop',
     'ورشة قصيرة لفريق الصيانة عن تنظيف الأجهزة وفحص التبريد.',
     'A short workshop for the maintenance team on cleaning devices and checking cooling.', 'workshop'),
    ('جدول الصيانة لهذا الأسبوع متاح الآن في قسم التقارير',
     'This week’s maintenance schedule is available in Reports',
     'افتح التقارير لمراجعة الأعمال المنجزة وخطة الإصلاح لهذا الأسبوع.',
     'Open Reports to review completed work and the repair plan for this week.', 'maintenance'),
)
DEMO_MARKER = 'review_data_seeded_v1'

def seeded_technicians(connection):
    people = list(connection.execute(
        "SELECT id,display_name FROM users WHERE username='tech' AND role='technician'"
    ))
    for handle, name in TECHNICIANS:
        username = f'demo.{handle}'
        result = connection.execute("""INSERT INTO users(username,password_hash,display_name,role)
            VALUES (?,?,?,'technician') ON CONFLICT(username) DO NOTHING""",
            (username, generate_password_hash(token_urlsafe(24)), name))
        if result.rowcount:
            people.append(connection.execute(
                'SELECT id,display_name FROM users WHERE id=?', (result.lastrowid,)
            ).fetchone())
    return people

def seed_review_data(connection, create_ticket, record_completion, notify, occupied_devices):
    if connection.execute('SELECT 1 FROM activity_log WHERE action=?', (DEMO_MARKER,)).fetchone():
        return
    today = date.today()
    people = seeded_technicians(connection)
    if not people:
        people = connection.execute(
            "SELECT id,display_name FROM users WHERE role='technician' ORDER BY id"
        ).fetchall()
    if not people:
        return
    admin = connection.execute(
        "SELECT id FROM users WHERE role='admin' ORDER BY username<>'admin', id LIMIT 1"
    ).fetchone()
    devices = []
    finished_day = today

    for slot in range(24):
        name, model, _ = EQUIPMENT[slot % len(EQUIPMENT)]
        department = DEPARTMENTS[slot // 4]
        tag = f'SAWN-DEMO-{slot + 1:03d}'
        result = connection.execute("""INSERT INTO devices(asset_tag,name,model,department)
            VALUES (?,?,?,?) ON CONFLICT(asset_tag) DO NOTHING""", (tag, name, model, department))
        if result.rowcount:
            devices.append((slot, result.lastrowid, tag))

    for slot, device_id, tag in devices:
        person = people[slot % len(people)]
        issues = EQUIPMENT[slot % len(EQUIPMENT)][2]
        for order, issue in enumerate(issues[:2 if slot < 12 else 1]):
            status = ('مكتمل', 'جديد', 'قيد الصيانة')[(slot + order) % 3]
            if status == 'مكتمل':
                while (len(occupied := occupied_devices(finished_day)) >= 5
                       and device_id not in occupied):
                    finished_day -= timedelta(days=1)
                finished = datetime.combine(finished_day, time(12)).isoformat(sep=' ')
                started = (datetime.fromisoformat(finished) - timedelta(days=1)).isoformat(sep=' ')
                result = connection.execute("""INSERT INTO tickets
                    (device_id,issue,technician,technician_id,status,planned_date,created_at,updated_at)
                    VALUES (?,?,?,?,?,?,?,?)""",
                    (device_id, issue, person['display_name'], person['id'], status,
                     finished_day.isoformat(), started, finished))
                record_completion('ticket', result.lastrowid, device_id, issue,
                                  person['display_name'], finished_day.isoformat())
            else:
                when = (today + timedelta(days=(slot + order) % 4)).isoformat()
                ticket_id = create_ticket(device_id, tag, issue, person, when)
                if status == 'قيد الصيانة':
                    connection.execute('UPDATE tickets SET status=? WHERE id=?', (status, ticket_id))

    for index, (_, device_id, tag) in enumerate(devices[:12]):
        person = people[index % len(people)]
        due = (today + timedelta(days=index % 5)).isoformat()
        if index < 8:
            connection.execute("""INSERT INTO schedules
                (device_id,kind,due_date,interval_days,assigned_to) VALUES (?,?,?,?,?)""",
                (device_id, MAINTENANCE_TYPES[index % len(MAINTENANCE_TYPES)], due, 90, person['id']))
        if admin:
            title = TASK_TITLES[index % len(TASK_TITLES)]
            status = ('pending', 'in_progress', 'completed')[index % 3]
            result = connection.execute("""INSERT INTO tasks
                (title,description,device_id,assigned_to,assigned_by,priority,status,due_date)
                VALUES (?,?,?,?,?,?,?,?)""",
                (title, f'تحقّق من حالة الجهاز {tag} وسجّل نتيجة الفحص.', device_id,
                 person['id'], admin['id'], 'high' if index % 4 == 0 else 'normal', status, due))
            if status == 'completed':
                record_completion('task', result.lastrowid, device_id, title,
                                  person['display_name'], today.isoformat(), person['id'])
            else:
                notify(person['id'], 'مهمة جديدة من الإدارة', f'{title} · {tag}', '/tasks')

    for ar, en, body_ar, body_en, category in ANNOUNCEMENTS:
        connection.execute("""INSERT INTO announcements
            (title_ar,title_en,body_ar,body_en,category) VALUES (?,?,?,?,?)""",
            (ar, en, body_ar, body_en, category))
    connection.execute('INSERT INTO activity_log(action) VALUES (?)', (DEMO_MARKER,))
